library(testthat)
library(Rceattle)

test_check("Rceattle")
